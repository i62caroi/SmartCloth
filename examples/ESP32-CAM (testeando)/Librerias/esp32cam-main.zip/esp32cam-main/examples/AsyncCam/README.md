# AsyncCam: camera on ESPAsyncWebServer

This example runs on ESP32-CAM board.
It demonstrates how to use esp32cam library with [ESPAsyncWebServer](https://github.com/me-no-dev/ESPAsyncWebServer) library.
The HTTP server supports both JPEG still image and MJPEG stream, and allows changing camera resolution on the fly.
To use this example, modify WiFi SSID+password, then upload to ESP32.
